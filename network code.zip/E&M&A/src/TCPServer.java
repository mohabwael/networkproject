import java.io.*; 
import java.net.*;
import java.util.Scanner; 

public class TCPServer {
	public static void main(String argv[]) throws IOException 
    { 
      int number , temp;
      ServerSocket s1= new ServerSocket(1342);
      Socket ss = s1.accept();
      Scanner sc = new Scanner (ss.getInputStream());
      number=sc.nextInt();
      temp=number*2;
      PrintStream p= new PrintStream (ss.getOutputStream());
      p.println(temp);
      
}}
